const MenuModel = require("../Model/MenuModel");
const PageModel = require("../Model/Pagemodel");
const SubMenuModel = require("../Model/SubmenuModel");
const NodeError = require("../Errors/NodeErr");
const {
  handlePostCommon,
  handleGetCommon,
  handleEditCommon,
  handleCommonDelete,
  handleUpdateCommon,
  handleCommonMenuData,handleGetCommonMenu
} = require("../utils/CommonHandler");
const { sendResponse, handleError } = require("../utils/responseHandler");


const handlePost = async (req, res, next) => {
  const uniqueFields = {};
  handlePostCommon(req, res, MenuModel, uniqueFields, next);
};

// const handleFrontapgeHeaderData = async (req, res, next) => {
//   const menuType = "header "; // Define the menu type you need
//   handleCommonMenuData(
//     req,
//     res,
//     next,
//     MenuModel,
//     menuType,
//     SubMenuModel,
//     PageModel
//   );
// };
const handleFrontapgeHeaderData = async (req, res, next) => {
  try {
    const aggregatedData = await MenuModel.find({
      menutype: { $regex: "header", $options: 'i'} ,
      publish: "yes",
    });
    // console.log("Aggregated Data:", aggregatedData);

    let arr = [];

    for (const key in aggregatedData) {
      // console.log("key",key)
      const element = aggregatedData[key];
      let pid = element._id;
      let submenuData = await SubMenuModel.find({ p_id: pid, publish: "yes" });
      // console.log("Submenu Data Length:", submenuData);

      let arr2 = [];

      let Page = await PageModel.findOne({ _id: element.menulink });
      
      let pageData = {
        pageName: Page ? Page.name : null,
        pageID: Page ? Page._id : null,
        slug: Page ? Page.slug : null,
      };
      console.log("Page Data for Main Menu Item:", pageData);

      if (submenuData.length > 0) {
        for (const key2 in submenuData) {
          const element2 = submenuData[key2];
          let Page = await PageModel.findOne({ _id: element2.menulink });
          console.log("Page Data WITH submenu:", Page);

          let json2 = {
            submenuName: element2.submenuname,
            submenupublish: element2.publish,
            submenulink: element2.menulink,
            submenuID: element2._id,
            subUrlLink: element2.subUrlLink,
            pageName: Page ? Page.name : null,
            pageID: Page ? Page._id : null,
            slug: Page ? Page.slug : null,
          };
          arr2.push(json2);
        }
      }

      let json = {
        menuName: element.name,
        menuType: element.menutype,
        menulink: element.menulink,
        urlLink: element.urlLink,
        menuID: element._id,
        submenu: arr2,         
        pageData: pageData,      
      };

      arr.push(json);
    }

    res.status(200).json(arr);
  } catch (error) {
    console.error("Error:", error);
    next(error);
  }
};

const handleFrontapgeLeftMenuData = async (req, res, next) => {
  try {
    const aggregatedData = await MenuModel.find({
      menutype: { $regex: "left", $options: 'i'} ,
      publish: "yes",
    });
    // console.log("Aggregated Data:", aggregatedData);

    let arr = [];

    for (const key in aggregatedData) {
      // console.log("key",key)
      const element = aggregatedData[key];
      let pid = element._id;
      let submenuData = await SubMenuModel.find({ p_id: pid, publish: "yes" });
      // console.log("Submenu Data Length:", submenuData);

      let arr2 = [];

      let Page = await PageModel.findOne({ _id: element.menulink });
      
      let pageData = {
        pageName: Page ? Page.name : null,
        pageID: Page ? Page._id : null,
        slug: Page ? Page.slug : null,
      };
      console.log("Page Data for Main Menu Item:", pageData);

      if (submenuData.length > 0) {
        for (const key2 in submenuData) {
          const element2 = submenuData[key2];
          let Page = await PageModel.findOne({ _id: element2.menulink });
          console.log("Page Data WITH submenu:", Page);

          let json2 = {
            submenuName: element2.submenuname,
            submenupublish: element2.publish,
            submenulink: element2.menulink,
            submenuID: element2._id,
            subUrlLink: element2.subUrlLink,
            pageName: Page ? Page.name : null,
            pageID: Page ? Page._id : null,
            slug: Page ? Page.slug : null,
          };
          arr2.push(json2);
        }
      }

      let json = {
        menuName: element.name,
        menuType: element.menutype,
        menulink: element.menulink,
        urlLink: element.urlLink,
        menuID: element._id,
        submenu: arr2,         
        pageData: pageData,      
      };

      arr.push(json);
    }

    res.status(200).json(arr);
  } catch (error) {
    console.error("Error:", error);
    next(error);
  }
};
const handleFrontapgeRightMenuData = async (req, res, next) => {
  try {
    const aggregatedData = await MenuModel.find({
      menutype: { $regex: "right", $options: 'i'} ,
      publish: "yes",
    });
    // console.log("Aggregated Data:", aggregatedData);

    let arr = [];

    for (const key in aggregatedData) {
      // console.log("key",key)
      const element = aggregatedData[key];
      let pid = element._id;
      let submenuData = await SubMenuModel.find({ p_id: pid, publish: "yes" });
      // console.log("Submenu Data Length:", submenuData);

      let arr2 = [];

      let Page = await PageModel.findOne({ _id: element.menulink });
      
      let pageData = {
        pageName: Page ? Page.name : null,
        pageID: Page ? Page._id : null,
        slug: Page ? Page.slug : null,
      };
      console.log("Page Data for Main Menu Item:", pageData);

      if (submenuData.length > 0) {
        for (const key2 in submenuData) {
          const element2 = submenuData[key2];
          let Page = await PageModel.findOne({ _id: element2.menulink });
          console.log("Page Data WITH submenu:", Page);

          let json2 = {
            submenuName: element2.submenuname,
            submenupublish: element2.publish,
            submenulink: element2.menulink,
            submenuID: element2._id,
            subUrlLink: element2.subUrlLink,
            pageName: Page ? Page.name : null,
            pageID: Page ? Page._id : null,
            slug: Page ? Page.slug : null,
          };
          arr2.push(json2);
        }
      }

      let json = {
        menuName: element.name,
        menuType: element.menutype,
        menulink: element.menulink,
        urlLink: element.urlLink,
        menuID: element._id,
        submenu: arr2,         
        pageData: pageData,      
      };

      arr.push(json);
    }

    res.status(200).json(arr);
  } catch (error) {
    console.error("Error:", error);
    next(error);
  }
};
// const handleFrontapgeLeftMenuData = async (req, res, next) => {
//   const menuType =  { $regex: "left", $options: 'i'}; // Define the menu type you need
//   handleCommonMenuData(
//     req,
//     res,
//     next,
//     MenuModel,
//     menuType,
//     SubMenuModel,
//     PageModel
//   )
// }


// const handleFrontapgeRightMenuData = async (req, res, next) => {
//   const menuType =  { $regex: "right", $options: 'i'}; // Define the menu type you need
//   handleCommonMenuData(
//     req,
//     res,
//     next,
//     MenuModel,
//     menuType,
//     SubMenuModel,
//     PageModel
//   );
// };


const handleGetMenuLinkData = async (req, res, next) => {
  const queryOptions = {};
  handleGetCommon(req, res, PageModel, queryOptions, next);
};

const handleGetAllData = async (req, res, next) => {
  try {
    const { page , pagesize } = req.query;
    const pagination = {
      pagesize, // Use 'pagesize' to match the expected parameter
      page, // Ensure 'page' is correctly passed
    };
    const queryOptions = {};
    handleGetCommonMenu(req, res, MenuModel, queryOptions, next, false, pagesize, page)
  } catch (error) {
    console.error('Error in handleGetAllData:', error);
    next(error);
  }
};



const handleUpdateCheckbox = async (req, res, next) => {
  const updateFields = {
    publish: req.params.publish
   };
  handleUpdateCommon(req, res, MenuModel, updateFields, next);
};


const handleDelete = async (req, res, next) => {
  handleCommonDelete(MenuModel, req.params.id, res, next);
};


const handleEdit = async (req, res, next) => {
  handleEditCommon(req, res, MenuModel, next);
};


const handleUpdate = async (req, res, next) => {
  const updateFields = {
    name: req.body.name,
    menulink: req.body.menulink,
    menutype: req.body.menutype,
    publish: req.body.publish,
    urlLink: req.body.urlLink,
  };
  handleUpdateCommon(req, res, MenuModel, updateFields, next);
};


module.exports = {
  handlePost,
  handleFrontapgeHeaderData,
  handleGetMenuLinkData,
  handleGetAllData,
  handleUpdateCheckbox,
  handleDelete,
  handleEdit,
  handleUpdate,
  handleFrontapgeRightMenuData,
  handleFrontapgeLeftMenuData,
};
