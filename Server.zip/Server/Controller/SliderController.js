const sliderModel = require("../Model/SliderModel");
const mongoose = require("mongoose");
const MediaModel = require("../Model/SliderFileupload");
const pagemodel = require("../Model/Pagemodel");
const {
  handlePostCommon,
  handleGetCommon,
  handleCommonDelete,
  handleUpdateCommon,
} = require("../utils/CommonHandler");
const NodeError = require("../Errors/NodeErr");
const { sendResponse, handleError } = require("../utils/responseHandler");


const handlePost = async (req, res, next) => {
  try {
    const { title, image, publish, pageName, editorContent, file } = req.body;

    // If pageName is empty, ensure there's only one record with an empty pageName
    if (!pageName) {
      const existingSlide = await sliderModel.findOne({ pageName: "" });
      if (existingSlide) {
        return res
          .status(400)
          .json({ error: "A slide with an empty pageName already exists." });
      }
    }

    // Fetch the page data to get the slug (if pageName is not empty)
    let pageSlug = null;
    if (pageName) {
      const page = await pagemodel.findOne({ name: pageName });
      pageSlug = page ? page.slug : null;
    }

    const slide = new sliderModel({
      title,
      image,
      publish,
      pageName,
      file,
      editorContent,
      pageSlug, // Save the slug if found
    });

    await slide.save();
    res.status(201).json({ message: "Slide saved successfully", slide });
  } catch (error) {
    res.status(500).json({ error: "Error saving slide" });
  }
};

const handleGetwithoutImage = async (req, res, next) => {
  const queryOptions = {};
  handleGetCommon(req, res, sliderModel, queryOptions, next);
};

// Example endpoint to update slide order
const handleupadteDragDrop = async (req, res) => {
  const { slideOrder } = req.body; // slideOrder is an array of slide IDs in the new order

  try {
    // Update each slide with its new order position
    await Promise.all(
      slideOrder.map((id, index) =>
        sliderModel.updateOne({ _id: id }, { $set: { order: index } })
      )
    );
    res.status(200).send({ message: "Slide order updated successfully" });
  } catch (error) {
    console.error("Error updating slide order:", error);
    res.status(500).send({ error: "Error updating slide order" });
  }
};


// Fetch all slides
const handleGet = async (req, res, next) => {
  try {
    const imageData = await sliderModel.find().sort({ order: 1 });

    const result = await Promise.all(imageData.map(async (sliderModelData) => {
      // Prepare the response object
      const element = {
        autoID: sliderModelData._id,
        title: sliderModelData.title,
        publish: sliderModelData.publish,
        editorContent: sliderModelData.editorContent,
        pageName: sliderModelData.pageName,
        file: sliderModelData.file,
        pageSlug: sliderModelData.pageSlug,
      };

      // If there are files, fetch their details
      if (sliderModelData.file && sliderModelData.file.length > 0) {
        try {
          // Fetch details for each file ID
          const files = await Promise.all(sliderModelData.file.map(fileId =>
            MediaModel.findById(fileId).exec()
          ));

          // Extract filenames from file details
          element.filename = files.map(file => file ? file.filename : "");
        } catch (fileError) {
          console.error("Error fetching media files:", fileError);
          element.filename = [];
        }
      } else {
        element.filename = [];
      }

      return element;
    }));

    // Log and send the result
    console.log(result);
    sendResponse(res, 200, result);

  
  } catch (error) {
    handleError(error, res);

    console.error("Error fetching slides:", error);
    next(error);
  }
};



const handleGetDataForBanner = async (req, res, next) => {
  try {
    const { pageSlug } = req.params;
    console.log("Page slug received:", pageSlug);

    // Ensure pageSlug is provided
    if (!pageSlug) {
      return res.status(400).json({ error: "Page slug is required" });
    }

    // Fetch data for the given pageSlug
    const imageData = await sliderModel.find({ pageSlug }).sort({ order: 1 }).exec();

    // If no data found, return a 404 error
    if (imageData.length === 0) {
      console.log(`No data found for pageSlug: ${pageSlug}`);
      return res.status(404).json({ message: `No data found for pageSlug: ${pageSlug}` });
    }

    // Process each item in the fetched data
    const result = await Promise.all(imageData.map(async (sliderModelData) => {
      // Prepare the response object
      const element = {
        autoID: sliderModelData._id,
        title: sliderModelData.title,
        publish: sliderModelData.publish,
        editorContent: sliderModelData.editorContent,
        pageName: sliderModelData.pageName,
        file: sliderModelData.file,
        pageSlug: sliderModelData.pageSlug,
      };

      // If there are files, fetch their details
      if (sliderModelData.file && sliderModelData.file.length > 0) {
        try {
          // Fetch details for each file ID
          const files = await Promise.all(sliderModelData.file.map(fileId =>
            MediaModel.findById(fileId).exec()
          ));

          // Extract filenames from file details
          element.filenames = files.map(file => file ? file.filename : "");
        } catch (fileError) {
          console.error("Error fetching media files:", fileError);
          element.filenames = [];
        }
      } else {
        element.filenames = [];
      }

      return element;
    }));

    // Log and send the result
    console.log(result);
    sendResponse(res, 200, result);
  } catch (error) {
    handleError(error, res);
    console.error("Error fetching slides:", error);
    next(error);
  }
};
const handleGetDataForHomeBanner = async (req, res, next) => {
  try {
    // Fetch data for the given pageSlug
    const imageData = await sliderModel.find({ pageName: "" }).sort({ order: 1 }).exec();

    // If no data found, return a 404 error
    if (imageData.length === 0) {
      return res.status(404).json({ message: `No data found for home ppage banner` });
    }

    // Process each item in the fetched data
    const result = await Promise.all(imageData.map(async (sliderModelData) => {
      // Prepare the response object
      const element = {
        autoID: sliderModelData._id,
        title: sliderModelData.title,
        publish: sliderModelData.publish,
        editorContent: sliderModelData.editorContent,
        pageName: sliderModelData.pageName,
        file: sliderModelData.file,
        pageSlug: sliderModelData.pageSlug,
      };

      // If there are files, fetch their details
      if (sliderModelData.file && sliderModelData.file.length > 0) {
        try {
          // Fetch details for each file ID
          const files = await Promise.all(sliderModelData.file.map(fileId =>
            MediaModel.findById(fileId).exec()
          ));

          // Extract filenames from file details
          element.filenames = files.map(file => file ? file.filename : "");
        } catch (fileError) {
          console.error("Error fetching media files:", fileError);
          element.filenames = [];
        }
      } else {
        element.filenames = [];
      }

      return element;
    }));

    // Log and send the result
    console.log(result);
    sendResponse(res, 200, result);
  } catch (error) {
    handleError(error, res);
    console.error("Error fetching slides:", error);
    next(error);
  }
};

const handleUpdateCheckbox = async (req, res, next) => {
  const updateFields = {
    publish: req.params.publish,
  };
  handleUpdateCommon(req, res, sliderModel, updateFields, next);
};

const handleDelete = async (req, res, next) => {
  handleCommonDelete(sliderModel, req.params.id, res, next);
};

const handleEdit = async (req, res, next) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      throw new NodeError(400, "Invalid ID");
    }
    const formData = await sliderModel.findById(req.params.id);
    if (!formData) {
      throw new NodeError(400, "Data not found");
    }

 

    // Construct the response object with form data and image details
    const imageDataArray = [];

    // Loop through the file array and fetch image details
    if (formData.file && formData.file.length > 0) {
      for (const fileId of formData.file) {
        const imageData = await MediaModel.findById(fileId);
        if (imageData) {
          imageDataArray.push({
            _id: imageData._id,
            filename: imageData.filename,
            // Add other image properties if necessary
          });
        }
      }
    }

    // Construct the response object with form data and image details
    const responseData = {
      formData: {
        _id: formData._id,
        title: formData.title,
        publish: formData.publish,
        editorContent: formData.editorContent,
        pageName: formData.pageName,
        file: formData.file,
        pageSlug: formData.pageSlug,
      },
      imageData: imageDataArray, // This will contain an array of all associated images
    };

    sendResponse(res, 200, responseData);
  } catch (error) {
    handleError(error, res);

    console.error("Error fetching data:", error);
    next(error);
  }
};


const handleUpdate = async (req, res, next) => {
  try {
    // Check if a new file is being uploaded
    let file;
    if (req.file) {
      file = req.file.path; // Assuming multer is being used to handle file uploads
    } else {
      file = req.body.file; // If no new file is uploaded, retain the existing file path
    }

    // Fetch the page slug based on pageName, set to null if pageName is empty or page not found
    let pageSlug = null;
    if (req.body.pageName) {
      const page = await pagemodel.findOne({ name: req.body.pageName });
      pageSlug = page ? page.slug : null;
    }

    // Check if another entry with an empty pageName already exists (ignoring the current record)
    if (req.body.pageName === "") {
      const existingEmptyPageName = await sliderModel.findOne({
        pageName: "",
        _id: { $ne: req.params.id }, // Ignore the current record being updated
      });

      if (existingEmptyPageName) {
        return res.status(400).json({
          error: "Another entry with an empty pageName already exists. Please provide a page name.",
        });
      }
    }

    // Update the slider data, including the conditionally set pageSlug
    const updatedFormData = await sliderModel.findByIdAndUpdate(
      req.params.id,
      {
        $set: {
          publish: req.body.publish,
          title: req.body.title,
          editorContent: req.body.editorContent,
          pageName: req.body.pageName,
          file: file,
          pageSlug: pageSlug, // Save the slug if found
        },
      },
      { new: true }
    );

    if (!updatedFormData) {
      throw new Error("Data not found");
    }

    sendResponse(res, 200, updatedFormData); // Send success response
  } catch (error) {
    handleError(error, res);
    next(error);
  }
};


//un updation tehre should no submission 
const handleFrontendDataShow = async (req, res, next) => {
  try {
    const imageData = await sliderModel.find({ publish: 1 });
    let arr = [];

    for (let index = 0; index < imageData.length; index++) {
      const sliderModelData = imageData[index];

      let element = {};
      element.autoID = sliderModelData._id;
      element.title = sliderModelData.title;
      element.publish = sliderModelData.publish;
      element.pageName = sliderModelData.pageName;
      element.editorContent = sliderModelData.editorContent;
      element.pageSlug = sliderModelData.pageSlug;
      element.file = sliderModelData.file;

      if (sliderModelData.file && sliderModelData.file.length > 0) {
        const newID =sliderModelData.file;
        const img = await MediaModel.findById(newID);
        if (img) {
          element.filename = img.filename;
        } else {
          element.filename = ""; // or some default value
        }
      } else {
        element.filename = ""; // or some default value
      }
      arr.push(element);
    }
    // console.log(arr);
    sendResponse(res, 200, arr);
  } catch (error) {
    handleError(error, res);
    next(error);
  }
};

module.exports = {
  handleupadteDragDrop,
  handleGet,
  handlePost,
  handleUpdateCheckbox,
  handleUpdate,
  handleDelete,
  handleEdit,
  handleGetwithoutImage,
  handleFrontendDataShow,
  handleGetDataForHomeBanner,handleGetDataForBanner
};
