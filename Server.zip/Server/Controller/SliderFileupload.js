const MediaModel = require('../Model/SliderFileupload')

const {
  
  handleGetCommon,
  handleGetToAnotherCommon,
  handleCommonFileUpload,
  } = require("../utils/CommonHandler");
  const { sendResponse, handleError } = require("../utils/responseHandler");

  const handleGet = async (req, res ,next) => {
    try {
      const { id } = req.params;
      if (!mongoose.Types.ObjectId.isValid(id)) {
        throw new NodeError(404, "Invalid ObjectId");
      }
      const image = await MediaModel.findById(id);
      if (!image) {
        throw new NodeError(404, "Image not found");
      }
      sendResponse(res, 200, image);
    } catch (error) {
      handleError(error, res);
     next(error)
    }
  }
const handlePost = ( async (req, res,next) => {

  const fileField = "filename"
  handleCommonFileUpload(req, res, MediaModel, fileField, next)

  })


  const handleGetImgtoPopup = async (req, res,next) => {  const queryOptions = {};

  handleGetCommon(req, res, MediaModel, queryOptions, next)
    
  }
  module.exports={handlePost,handleGetImgtoPopup,handleGet}