const TestimonialUploadModel = require('../Model/TestimonialUpload')
const mongoose = require('mongoose')
const {
  
  handleGetCommon,
  
  handleCommonFileUpload,
  } = require("../utils/CommonHandler");


const NodeError = require('../Errors/NodeErr')


  const { sendResponse, handleError } = require("../utils/responseHandler");

  const handleGet = async (req, res ,next) => {
    try {
      const { id } = req.params;
      if (!mongoose.Types.ObjectId.isValid(id)) {
        throw new NodeError(404, "Invalid ObjectId");
      }
      const image = await TestimonialUploadModel.findById(id);
      if (!image) {
        throw new NodeError(404, "Image not found");
      }
      sendResponse(res, 200, image);
    } catch (error) {
      handleError(error, res);
     next(error)
    }
  }
const handlePost = ( async (req, res,next) => {

  const fileField = "filename"
  handleCommonFileUpload(req, res, TestimonialUploadModel, fileField, next)

  })


  const handleGetImgtoPopup = async (req, res,next) => {  const queryOptions = {};

  handleGetCommon(req, res, TestimonialUploadModel, queryOptions, next)
    
  }
  module.exports={handlePost,handleGetImgtoPopup,handleGet}