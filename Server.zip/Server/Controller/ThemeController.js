// controllers/themeController.js
const Theme = require("../Model/ThemeModel");
const path = require("path");
const fs = require("fs");
// const unzipper = require('unzipper');
const AdmZip = require("adm-zip");

// Recursive function to read contents of directories and files
const readDirectoryContents = (dirPath) => {
  return new Promise((resolve, reject) => {
    fs.readdir(dirPath, (err, items) => {
      if (err) {
        return reject(err);
      }

      let results = [];
      let pending = items.length;

      if (!pending) return resolve(results); // No items to process

      items.forEach((item) => {
        const itemPath = path.join(dirPath, item);

        fs.stat(itemPath, (err, stats) => {
          if (err) {
            return reject(err);
          }

          if (stats.isDirectory()) {
            // Recursively read subdirectory
            readDirectoryContents(itemPath)
              .then((subItems) => {
                results.push({
                  type: "Folder",
                  name: item,
                  contents: subItems,
                });
                if (!--pending) resolve(results);
              })
              .catch(reject);
          } else {
            // Read file content
            fs.readFile(itemPath, "utf8", (err, data) => {
              if (err) {
                return reject(err);
              }

              // Push file name and content
              results.push({
                type: "File",
                name: item,
              });

              if (!--pending) resolve(results);
            });
          }
        });
      });
    });
  });
};

exports.uploadTheme = async (req, res) => {
  try {
    const filePath = path.join(__dirname, "../uploads/", req.file.filename);
    const extractPath = path.join(__dirname, "../../Frontend");

    // Ensure the extraction directory exists
    if (!fs.existsSync(extractPath)) {
      fs.mkdirSync(extractPath, { recursive: true });
    }

    console.log(`Extracting files from: ${filePath} to ${extractPath}`);

    // Extract ZIP file using adm-zip
    const zip = new AdmZip(filePath);
    const zipEntries = zip.getEntries();

    let themeName = "";
    let themeImage = ""; // To store the specific theme image path
    const imageExtensions = [".png", ".jpg",".webp", ".jpeg", ".gif"];


    // Loop through the zip entries to get the theme folder name
    zipEntries.forEach((entry) => {
      if (entry.isDirectory) {
        if (!themeName) {
          themeName = entry.entryName.split("/")[0];
        }
      }

      //If the entry is an image and located directly under the theme root folder
      if (
        !entry.isDirectory &&
        imageExtensions.some((ext) => entry.entryName.toLowerCase().endsWith(ext))
      ) {
        // Split the entry name and check if it is directly under the theme folder
        const parts = entry.entryName.split('/');
    
        // Check if it's in the root (i.e., only has two parts: [themeName, imageName])
        if (parts.length === 2 && parts[0] === themeName) {
          themeImage = entry.entryName; // Store the first image found in the root folder
        }
      }
    });
    console.log("Theme image path:", themeImage);
    // Check if the theme folder already exists
    const themeFolder = path.join(extractPath, themeName);
    // console.log(themeFolder)
 // Check if the theme with the same name already exists (case-insensitive and trimmed)

    // Check if the theme with the same name already exists
    const existingTheme = await Theme.findOne({ themeName: themeName });
    if (existingTheme) {
      return res.status(400).json({ message: `Theme with name '${themeName}' already exists. Please upload a different theme.` });
    }


    // Proceed with extracting the files
    zip.extractAllTo(extractPath, true); // 'true' will overwrite files, but the extraction is prevented above

    const files = await readDirectoryContents(extractPath); // assuming this returns file objects

    // Create a JSON file with theme information
    const themeInfo = {
      themeName: themeName,
      themeImage: themeImage, // Store the path of the specific image
      createdDate: new Date().toISOString(),
    };

    const jsonFilePath = path.join(themeFolder, 'theme-info.json');
    fs.writeFileSync(jsonFilePath, JSON.stringify(themeInfo, null, 2), 'utf-8');

    // Read theme name from the JSON file (if required)
// Read theme name and image path from the JSON file
const themeData = JSON.parse(fs.readFileSync(jsonFilePath, 'utf-8'));

// Check if the image exists in the theme folder
const imagePath = path.join(extractPath, themeData.themeImage);
if (!fs.existsSync(imagePath)) {
  return res.status(404).json({ message: "Theme image file not found." });
}
    // Fetch active theme (if any)
    const activeTheme = await Theme.findOne({ themeStatus: 1 });
    const themeStatus = activeTheme ? 0 : 1;
    const uniqueThemeCount = await Theme.distinct("themeName").then((names) => names.length);

    // Save the extracted data to the database using the theme name from the JSON file
    const newTheme = new Theme({
      themeName: themeData.themeName,
      numberOfFoldersExtracted: await Theme.countDocuments(),
      themeStatus,
      images: themeData.themeImage, 
      contents: files.map((file) => ({
        name: file.name || file,
        type: file.type || "file",
      })) ,
    });

    await newTheme.save();

    res.json({
      message: "File uploaded, extracted, and stored in the database successfully!",
      themeName: themeData.themeName,
      numberOfFoldersExtracted: await Theme.countDocuments(),
      themeStatus: themeStatus || 1,
      contents: files.map((file) => ({
        name: file.name || file,
        type: file.type || "file",
      })),
      images: themeData.themeImage,
      jsonFilePath: jsonFilePath,
    });
  } catch (error) {
    console.error("Error in uploadTheme:", error);
    res.status(500).json({ message: "Error extracting file: " + error.message });
  }
};



exports.getThemeByName = async (req, res) => {
  try {
    const theme = await Theme.find();
    if (!theme) {
      return res.status(404).json({ message: "Theme not found." });
    }
    res.json(theme);
  } catch (error) {
    console.error("Error retrieving theme:", error);
    res
      .status(500)
      .json({ message: "Error retrieving theme: " + error.message });
  }
};

exports.updatedTheme = async (req, res) => {
  const { themeName, themeStatus } = req.body; // Destructure from request body

  try {
    // If the new status is active (1), deactivate all other themes first
    if (themeStatus === 1) {
      await Theme.updateMany({}, { themeStatus: 0 }); // Deactivate all themes
    }

    // Update the selected theme's status
    const updatedTheme = await Theme.findOneAndUpdate(
      { _id: themeName }, // Assuming themeName is actually the ID; adjust if needed
      { themeStatus: themeStatus },
      { new: true } // Return the updated document
    );

    if (!updatedTheme) {
      return res.status(404).json({ message: "Theme not found" });
    }

    res.json({ message: "Theme status updated successfully", updatedTheme });
  } catch (error) {
    console.error("Error updating theme status:", error);
    res
      .status(500)
      .json({ message: "Error updating theme status: " + error.message });
  }
};

exports.deleteTheme = async (req, res) => {
  const id = req.params.id; // Get the theme ID from the request parameters

  try {
    // Find the theme in the database by its ID
    const theme = await Theme.findById(id);
    if (!theme) {
      return res.status(404).json({ message: "Theme record not found in the database." });
    }

    // Check if the theme is active
    if (theme.themeStatus === 1) {
      return res.status(400).json({ message: "Active theme cannot be deleted." });
    }

    // Determine the theme folder path in the project directory
    const themeFolderPath = path.join(__dirname, "../../Frontend", theme.themeName);

    // Check if the theme directory exists in the file system
    if (fs.existsSync(themeFolderPath)) {
      // Delete the theme folder and all its contents
      fs.rmSync(themeFolderPath, { recursive: true, force: true });
      console.log(`Theme folder '${theme.themeName}' deleted successfully.`);
    } else {
      console.warn(`Theme folder '${theme.themeName}' does not exist in the file system.`);
    }

    // Remove the theme record from the database
    await Theme.findByIdAndDelete(id);

    // Send a success response
    res.json({
      message: "Theme deleted successfully from both the file system and the database.",
    });
  } catch (error) {
    console.error("Error in deleteTheme:", error);
    res.status(500).json({ message: "Error deleting theme: " + error.message });
  }
};
