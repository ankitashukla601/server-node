const mongoose = require('mongoose')
const AlbumUploadSchema = new mongoose.Schema({
    filename: String,
  });
  
  const AlbumUploadModel = mongoose.model("AlbumUploadModel", AlbumUploadSchema);

  module.exports = AlbumUploadModel;