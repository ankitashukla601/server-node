const mongoose = require('mongoose');

const commentSchema = new mongoose.Schema({

  blogId: {
    type: mongoose.Schema.Types.ObjectId, // Type is ObjectId
    ref: 'BlogData', // Refers to the BlogData collection
  },
  name: { type: String, required: true },
  email: { type: String, required: true },
  comments: { type: String, required: true },
 
}, { timestamps: true });

module.exports = mongoose.model('CommentModel', commentSchema);
