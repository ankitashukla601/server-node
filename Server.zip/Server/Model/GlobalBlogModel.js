
const mongoose = require('mongoose')
const GlobalBlogSchema = new mongoose.Schema({

disBlog:Number,
blogCmnt:Number,
disBlogSlug:String,
blogCmntSlug:String,
cmntApprove:Number,
cmntApproveSlug:String,
blogGrid:Number,
blogGridSlug:String,
blogLayout:Number,
blogLayoutSlug:String,
sidebarContent:Number,
sidebarContentSlug:String,
postPerPage:Number,
postPerPageSlug:String

})

const GlobalBlogModel = mongoose.model('GlobalBlogData',GlobalBlogSchema)

module.exports= GlobalBlogModel