
const mongoose = require('mongoose')
const GlobalProductSchema = new mongoose.Schema({

    description: String,
    enquiry: String,
    disProduct: Number,
    productPerPage: Number,
    productPerRow: Number,
    descriptionSlug:String,
    enquirySlug:String,
    disProductSlug:String,
    productPerPageSlug:String,
    productPerRowSlug:String


})

const GlobalProductModel = mongoose.model('GlobalProductData',GlobalProductSchema)

module.exports= GlobalProductModel