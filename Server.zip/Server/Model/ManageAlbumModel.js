const mongoose = require('mongoose');

//mange album
const manageAlbumSchema = new mongoose.Schema({
  file: Array,
  title: String,
  publish: Number, 
  editorContent: String,

  });
  
  const manageAlbumModel = mongoose.model("manageAlbum", manageAlbumSchema);
  module.exports = manageAlbumModel
