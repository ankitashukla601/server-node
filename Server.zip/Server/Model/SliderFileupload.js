const mongoose = require('mongoose')
const mediaSchema = new mongoose.Schema({
    filename: Array,
  });
  
  const FileuploadModel = mongoose.model("SliderFileuploadModel", mediaSchema);

  module.exports = FileuploadModel;