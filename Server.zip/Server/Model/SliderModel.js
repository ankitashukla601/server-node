const mongoose = require("mongoose");
const sliderSchema = new mongoose.Schema({
  file: Array,
  title: String,
  publish: Number,
  editorContent: String,
  order: { type: Number, default: 0 },
  pageName: String,
  pageSlug: String, // Add slug to store the page slug
});

//add slide
const sliderModel = mongoose.model("sliderdata", sliderSchema);
module.exports = sliderModel;
