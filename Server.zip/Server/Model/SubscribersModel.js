const mongoose = require('mongoose');
const { type } = require('os');

const subscribersSchema = new mongoose.Schema({
  name: { type: String, },
  email: { type: String },
  publish:{type:Number}
  
});

const subscribersModel = mongoose.model('subscribersData', subscribersSchema);

module.exports = subscribersModel;
