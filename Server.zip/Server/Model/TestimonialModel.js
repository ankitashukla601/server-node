
const mongoose = require('mongoose')
const testimonialSchema = new mongoose.Schema({
    file: Array,
    title: String,
    description:String,
    publish: Number, 
    profile:String
  });
  
  //add slide
  const testimonialModel = mongoose.model("testimonialdata", testimonialSchema);
  module.exports = testimonialModel

