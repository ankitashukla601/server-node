const mongoose = require('mongoose')
const testmonialUploadSchema = new mongoose.Schema({
    filename: String,
  });
  
  const TestimonialUploadModel = mongoose.model("TestimonialUploadModel", testmonialUploadSchema);

  module.exports = TestimonialUploadModel;