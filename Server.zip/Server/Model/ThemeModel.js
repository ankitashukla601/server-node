const mongoose = require('mongoose');

const themeSchema = new mongoose.Schema(    {         
  themeName: {
    type: String,
    required: true,
  },
  numberOfFoldersExtracted: {
    type: Number,
    required: true,
  },
  images:Array,
  themeStatus: {
    type: Number,
  },
  uploadedAt: {       
    type: Date,
    default: Date.now,
  },
});

const Theme = mongoose.model('Theme', themeSchema);

module.exports = Theme;
