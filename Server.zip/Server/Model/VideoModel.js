const mongoose = require('mongoose')

//add video
const videoSchema = new mongoose.Schema({
    title: String,
    description: String,
    url: String,
    publish: Number,
    frontpage:Number
  });
  
  const videoModel = mongoose.model("videoData", videoSchema)

  module.exports = videoModel


