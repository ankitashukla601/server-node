const express = require('express')
const router = express.Router()
const upload= require('../MulterStorage')

const {handlePost,handleGetImgtoPopup,handleGet} = require('../Controller/BlogUploadController')
router.route("/add/blog/img/:id").get(handleGet);

router.route('/upload/blog/img').post(upload.single("file"),handlePost)
router.route('/get/uploaded/blog/img').get(handleGetImgtoPopup)
module.exports = router;