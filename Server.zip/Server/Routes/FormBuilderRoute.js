const express = require('express')
const router= express.Router()
const {handlePostFormDefinition,handleEdit,handleUpdate,handleDelete,handleGetFormDefinition,handleGetFormioData,handlePostFormioData,handleFrontendDataShow,handlePublishCheckboxUpdate,handleDeleteFormData}= require('../Controller/FormBuilderController')

//saving form fields
router.route('/save-form-definition').post(handlePostFormDefinition)

//getting  form name and publish in table
router.route('/form-definition').get(handleGetFormDefinition)
// save form fileds data
router.route('/save-form-data').post(handlePostFormioData)
// getting  saved form fileds data
router.route('/content').get(handleGetFormioData)

router.route('/show/frontend/formio').get(handleFrontendDataShow)
router.put('/formio/toggle/:id/:publish', handlePublishCheckboxUpdate);
// edit  saved form  fileds
router.route('/get/formio/data/:id').get(handleEdit)
// delete  saved form  fileds
router.route('/delete/formio/:id').delete(handleDelete)
// update  saved form  fileds
router.route('/update/formio/:id').put(handleUpdate)
// delete  saved form fileds data
router.route('/delete/inputs/data/values/:id').delete(handleDeleteFormData)

// router.route("/update-slide-checkbox/:id/:frontpage").get(handleSubmitCheckBox);
module.exports= router;