const express = require('express')
const router = express.Router()
const {handlePost,handleGet,handleFrontendDataShow,handleGetFrontpageToHome,handleEdit,handleGetLandingToFrontend,handleDelete,handleUpdate,handlePublishpageCheckboxUpdate,handleFrontpageCheckboxUpdate, handleFrontendDataShowUsingSlug} = require('../Controller/PageController')


router.route('/submit-form').post(handlePost)
router.route('/get-landing-form-data/:slug').get(handleGetLandingToFrontend)
router.route('/get-frontpage-home-form-data').get(handleGetFrontpageToHome)
router.route('/get-form-data').get(handleGet)

router.route('/get-frontpage-data-to-home').get(handleFrontpageCheckboxUpdate)
router.route('/get-forntend-data/:slug').get(handleFrontendDataShow)
router.route('/get-pages-data/:slug').get(handleFrontendDataShowUsingSlug)
router.route('/get-edit-form-data/:id').get(handleEdit)
router.route('/delete/:id').delete(handleDelete)
router.route('/edit/:id').put(handleUpdate)
router.route('/update-checkbox/:id/:frontpage').get(handleFrontpageCheckboxUpdate)
router.route('/update-checkbox2/:id/:published').get(handlePublishpageCheckboxUpdate)

// router.route('/submit-form').get(handlePost)
module.exports= router;