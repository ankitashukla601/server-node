const express = require('express')
const router = express.Router()
const upload= require('../MulterStorage')

const {handlePost,handleGetImgtoPopup,handleGet} = require('../Controller/SliderFileupload')

router.route('/upload-img').post(upload.single("file"),handlePost)
router.route('/get-img').get(handleGetImgtoPopup)
router.route('/add/upload/slider/img/:id').get(handleGet)
module.exports = router;