const express = require('express')
const router = express.Router()

const {handlePost,handleGet,handlePublishCheckboxUpdate,handleDelete} = require('../Controller/SubscribersCont')

router.route('/submit/subscribers/data').post(handlePost)
router.route('/get/subscriber/data').get(handleGet)
router.route('/update/subscriber/status/:id/:publish').get(handlePublishCheckboxUpdate)
router.route('/delete/subscriber/:id').delete(handleDelete)
module.exports = router;