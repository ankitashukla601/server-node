


const express = require("express");
const router = express.Router();

const {
  handlePost,
  handleGet,
  handleUpdateCheckbox,
  handleDelete,
  handleEdit,
  handleUpdate,
  handleGetwithoutImage,handleFrontendDataShow,handleupadteDragDrop
} = require("../Controller/TestimonialsCont");
const upload = require('../MulterStorage')



router.route("/add/testimonial").post( upload.array('file'),handlePost);
router.route("/get/testimonial").get( handleGet);
router.route("/get/testimonial/without/image").get(handleGetwithoutImage);
router.route("/delete/testimonial/img/:id").delete(handleDelete);
router.route("/update/testimonial/checkbox/:id/:publish").get(handleUpdateCheckbox);
router.route("/get-testimonial-data/:id").get(handleEdit);
router.route("/update/testimonial/:id").put(upload.single('file'), handleUpdate);
router.route('/show/testimonial/forntend/data').get(handleFrontendDataShow)



module.exports = router;
