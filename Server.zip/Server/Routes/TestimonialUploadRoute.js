const express = require('express')
const router = express.Router()
const upload= require('../MulterStorage')

const {handlePost,handleGetImgtoPopup,handleGet} = require('../Controller/TestimonialUploadCont')

router.route('/upload/testimonial/img').post(upload.single("file"),handlePost)
router.route('/get/testimonial/img').get(handleGetImgtoPopup)
router.route('/add/uploaded/testimonial/img/:id').get(handleGet)
module.exports = router;