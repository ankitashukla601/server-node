// routes/themeRoutes.js
const express = require('express');
const multer = require('multer');
const themeController = require('../Controller/ThemeController');

const router = express.Router();

const upload = multer({ dest: 'uploads/' }); // Define where to save uploaded files
// Define routes
router.post('/upload', upload.single('file'), themeController.uploadTheme);
router.get('/theme-name',themeController.getThemeByName);
router.delete('/delete-theme/:id', themeController.deleteTheme);
router.put('/update-theme-status',themeController.updatedTheme) // New route for deleting files
// router.put('/update-all-themes-status',themeController) // New route for deleting files

module.exports = router;
