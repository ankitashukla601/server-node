const express = require('express')
const router = express.Router()
const {handlePost,handleGet,handleEdit,handleDelete,handleUpdate,} = require('../Controller/WidgetThemeCont')


router.route('/submit/widget').post(handlePost)
router.route('/get/widget').get(handleGet)

router.route('/edit/widget/:id').get(handleEdit)
router.route('/delete/widget/:id').delete(handleDelete)
router.route('/update/widget/:id').put(handleUpdate)


// router.route('/submit-form').get(handlePost)
module.exports= router;